function fun(n){
    /*hile(n)
    if(n=='*' | n=='+' n=='/' | n=='-')
    {
        var a=num;
        operator(num,op);
    }*/
    txt.value+=n;
}